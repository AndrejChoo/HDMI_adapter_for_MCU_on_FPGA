/*
 * gpio.c
 *
 *  Created on: 7 ��� 2024 �.
 *      Author: Andrej
 */

#include "gpio.h"

void gpio_init(void)
{
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;
	GPIO_InitTypeDef pin;

	//AD BUS
	pin.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	pin.GPIO_Mode = GPIO_Mode_OUT;
	pin.GPIO_OType = GPIO_OType_PP;
	pin.GPIO_Speed = GPIO_High_Speed;
	GPIO_Init(GPIOA, &pin);

	//CMD and Strobe PINs
	pin.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_10;
	GPIO_Init(GPIOB, &pin);

	//Strobe LOW
	GPIO_ResetBits(GPIOB, GPIO_Pin_2);
}
