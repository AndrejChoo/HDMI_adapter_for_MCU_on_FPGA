/*
 * gpio.h
 *
 *  Created on: 7 ��� 2024 �.
 *      Author: Andrej
 */

#ifndef GPIO_H_
#define GPIO_H_

#include "stm32f4xx.h"

/*
 * DATA[7:0] - GPIOA[7:0]
 * CMD[2:0]  - {GPIOB[10],GPIOB[1:0]}
 * STROBE    - GPIOB[2]
 */

void gpio_init(void);

#endif /* GPIO_H_ */
