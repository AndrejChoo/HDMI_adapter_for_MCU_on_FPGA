/*
 * delay.h
 *
 *  Created on: 8 ��� 2024 �.
 *      Author: Andrej
 */

#ifndef DELAY_H_
#define DELAY_H_

#include "stm32f4xx.h"

void delay_init(void);
void delay_ms(uint16_t ms);
void delay_us(uint16_t us);

#endif /* DELAY_H_ */
